function frog(x, y){
  this.x = x;
  this.y = y;
  imageMode(CENTER);
  image(img, this.x, this.y);
 }
